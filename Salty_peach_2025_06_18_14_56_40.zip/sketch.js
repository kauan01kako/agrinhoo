let sementes = [];  // Array para armazenar as sementes

function setup() {
  createCanvas(600, 400);
  noStroke();
}

function draw() {
  background(220, 250, 220);  // Cor de fundo (céu claro)

  // Desenho do solo
  fill(139, 69, 19);  // Cor de solo
  rect(0, height - 50, width, 50);  // Solo

  // Atualizar e desenhar cada semente
  for (let i = 0; i < sementes.length; i++) {
    sementes[i].update();
    sementes[i].display();
  }
}

// Função para plantio de sementes (clicar na tela)
function mousePressed() {
  sementes.push(new Semente(mouseX, mouseY));
}

// Classe para representar as sementes
class Semente {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 5;
    this.growRate = 0.2;  // Taxa de crescimento
    this.crescendo = true;
  }

  // Função de atualização do crescimento
  update() {
    if (this.crescendo && this.tamanho < 20) {
      this.tamanho += this.growRate;
    } else if (this.tamanho >= 20) {
      this.crescendo = false;  // A planta já atingiu seu tamanho máximo
    }
  }

  // Função para desenhar a semente/planta
  display() {
    fill(0, 128, 0);  // Cor da planta (verde)
    ellipse(this.x, this.y - this.tamanho / 2, this.tamanho, this.tamanho);  // Planta
  }
}
